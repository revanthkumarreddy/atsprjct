# ats
employee-attendance-and-salary-managenemt

Extract ats.zip Install xaamp software copy the extracted folder in to the htdocs folder of xaamp directory create mysql database using .sql file provided in the extracted folder run the project using browcer as localhost
